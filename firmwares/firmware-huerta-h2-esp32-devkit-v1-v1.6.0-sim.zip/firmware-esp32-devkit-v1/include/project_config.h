#pragma once

#define FIRMWARE_VERSION "1.6.0-sim"
#define SUPABASE_URL "https://jvrrtwlejbymxskijdhj.supabase.co"
#define ENROLL_ENDPOINT SUPABASE_URL "/functions/v1/device-enroll"

#define MQTT_HOST "broker.emqx.io"
#define MQTT_PORT 8883
#define MQTT_ROOT "huertaiot"

#define TELEMETRY_INTERVAL_MS 15000UL
#define ENROLL_RETRY_MS 60000UL
#define WIFI_RETRY_MS 10000UL
#define MQTT_RETRY_MS 5000UL

// false: relé activo en HIGH. Cambiar a true para módulos de relé activos en LOW.
#define RELAY_ACTIVE_LOW false

