#pragma once

// Copiar este archivo como include/secrets.h y completar los tres valores.
#define WIFI_SSID "NOMBRE_WIFI"
#define WIFI_PASSWORD "CLAVE_WIFI"

// Debe coincidir con DEVICE_ENROLLMENT_KEY en Supabase Secrets.
#define DEVICE_ENROLLMENT_KEY "CAMBIAR_POR_CLAVE_ALEATORIA_DE_32_CARACTERES"

